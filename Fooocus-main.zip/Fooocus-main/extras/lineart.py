import functools
import math

import cv2
import numpy as np
import torch
import torch.nn as nn

import ldm_patched.modules.model_management


# ---------------------------------------------------------------------------
# Anime2Sketch (netG.pth) - pix2pix U-Net used by the "lineart_anime" preprocessor
# Architecture mirrors the reference implementation so the published weights
# load with strict=True.
# ---------------------------------------------------------------------------

class _UnetSkipConnectionBlock(nn.Module):
    def __init__(self, outer_nc, inner_nc, input_nc=None,
                 submodule=None, outermost=False, innermost=False,
                 norm_layer=nn.BatchNorm2d, use_dropout=False):
        super().__init__()
        self.outermost = outermost
        if type(norm_layer) == functools.partial:
            use_bias = norm_layer.func == nn.InstanceNorm2d
        else:
            use_bias = norm_layer == nn.InstanceNorm2d
        if input_nc is None:
            input_nc = outer_nc
        downconv = nn.Conv2d(input_nc, inner_nc, kernel_size=4,
                             stride=2, padding=1, bias=use_bias)
        downrelu = nn.LeakyReLU(0.2, True)
        downnorm = norm_layer(inner_nc)
        uprelu = nn.ReLU(True)
        upnorm = norm_layer(outer_nc)

        if outermost:
            upconv = nn.ConvTranspose2d(inner_nc * 2, outer_nc,
                                        kernel_size=4, stride=2, padding=1)
            down = [downconv]
            up = [uprelu, upconv, nn.Tanh()]
            model = down + [submodule] + up
        elif innermost:
            upconv = nn.ConvTranspose2d(inner_nc, outer_nc,
                                        kernel_size=4, stride=2, padding=1,
                                        bias=use_bias)
            down = [downrelu, downconv]
            up = [uprelu, upconv, upnorm]
            model = down + up
        else:
            upconv = nn.ConvTranspose2d(inner_nc * 2, outer_nc,
                                        kernel_size=4, stride=2, padding=1,
                                        bias=use_bias)
            down = [downrelu, downconv, downnorm]
            up = [uprelu, upconv, upnorm]
            if use_dropout:
                model = down + [submodule] + up + [nn.Dropout(0.5)]
            else:
                model = down + [submodule] + up

        self.model = nn.Sequential(*model)

    def forward(self, x):
        if self.outermost:
            return self.model(x)
        return torch.cat([x, self.model(x)], 1)


class UnetGenerator(nn.Module):
    def __init__(self, input_nc, output_nc, num_downs, ngf=64,
                 norm_layer=nn.BatchNorm2d, use_dropout=False):
        super().__init__()
        unet_block = _UnetSkipConnectionBlock(
            ngf * 8, ngf * 8, input_nc=None, submodule=None,
            norm_layer=norm_layer, innermost=True)
        for _ in range(num_downs - 5):
            unet_block = _UnetSkipConnectionBlock(
                ngf * 8, ngf * 8, input_nc=None, submodule=unet_block,
                norm_layer=norm_layer, use_dropout=use_dropout)
        unet_block = _UnetSkipConnectionBlock(
            ngf * 4, ngf * 8, input_nc=None, submodule=unet_block, norm_layer=norm_layer)
        unet_block = _UnetSkipConnectionBlock(
            ngf * 2, ngf * 4, input_nc=None, submodule=unet_block, norm_layer=norm_layer)
        unet_block = _UnetSkipConnectionBlock(
            ngf, ngf * 2, input_nc=None, submodule=unet_block, norm_layer=norm_layer)
        self.model = _UnetSkipConnectionBlock(
            output_nc, ngf, input_nc=input_nc, submodule=unet_block,
            outermost=True, norm_layer=norm_layer)

    def forward(self, x):
        return self.model(x)


# ---------------------------------------------------------------------------
# Informative drawings (sk_model.pth) - ResNet generator used by the
# "lineart" (realistic) preprocessor.
# ---------------------------------------------------------------------------

class _LineartResidualBlock(nn.Module):
    def __init__(self, in_features):
        super().__init__()
        self.conv_block = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(in_features, in_features, 3),
            nn.InstanceNorm2d(in_features),
            nn.ReLU(inplace=True),
            nn.ReflectionPad2d(1),
            nn.Conv2d(in_features, in_features, 3),
            nn.InstanceNorm2d(in_features),
        )

    def forward(self, x):
        return x + self.conv_block(x)


class LineartGenerator(nn.Module):
    def __init__(self, input_nc, output_nc, n_residual_blocks=9, sigmoid=True):
        super().__init__()

        self.model0 = nn.Sequential(
            nn.ReflectionPad2d(3),
            nn.Conv2d(input_nc, 64, 7),
            nn.InstanceNorm2d(64),
            nn.ReLU(inplace=True),
        )

        model1 = []
        in_features = 64
        out_features = in_features * 2
        for _ in range(2):
            model1 += [
                nn.Conv2d(in_features, out_features, 3, stride=2, padding=1),
                nn.InstanceNorm2d(out_features),
                nn.ReLU(inplace=True),
            ]
            in_features = out_features
            out_features = in_features * 2
        self.model1 = nn.Sequential(*model1)

        self.model2 = nn.Sequential(*[_LineartResidualBlock(in_features) for _ in range(n_residual_blocks)])

        model3 = []
        out_features = in_features // 2
        for _ in range(2):
            model3 += [
                nn.ConvTranspose2d(in_features, out_features, 3, stride=2, padding=1, output_padding=1),
                nn.InstanceNorm2d(out_features),
                nn.ReLU(inplace=True),
            ]
            in_features = out_features
            out_features = in_features // 2
        self.model3 = nn.Sequential(*model3)

        model4 = [nn.ReflectionPad2d(3), nn.Conv2d(64, output_nc, 7)]
        if sigmoid:
            model4 += [nn.Sigmoid()]
        self.model4 = nn.Sequential(*model4)

    def forward(self, x):
        out = self.model0(x)
        out = self.model1(out)
        out = self.model2(out)
        out = self.model3(out)
        return self.model4(out)


# ---------------------------------------------------------------------------
# MangaLineExtraction (erika.pth) - residual encoder/decoder for "manga_line"
# ---------------------------------------------------------------------------

class _BnReluConv(nn.Module):
    def __init__(self, in_filters, nb_filters, fw, fh, subsample=1):
        super().__init__()
        self.model = nn.Sequential(
            nn.BatchNorm2d(in_filters, eps=1e-3),
            nn.LeakyReLU(0.2),
            nn.Conv2d(in_filters, nb_filters, (fw, fh), stride=subsample,
                      padding=(fw // 2, fh // 2), padding_mode='zeros')
        )

    def forward(self, x):
        return self.model(x)


class _UpBnReluConv(nn.Module):
    def __init__(self, in_filters, nb_filters, fw, fh, subsample=1):
        super().__init__()
        self.model = nn.Sequential(
            nn.BatchNorm2d(in_filters, eps=1e-3),
            nn.LeakyReLU(0.2),
            nn.Conv2d(in_filters, nb_filters, (fw, fh), stride=subsample,
                      padding=(fw // 2, fh // 2)),
            nn.Upsample(scale_factor=2, mode='nearest')
        )

    def forward(self, x):
        return self.model(x)


class _Shortcut(nn.Module):
    def __init__(self, in_filters, nb_filters, subsample=1):
        super().__init__()
        self.process = in_filters != nb_filters or subsample != 1
        self.model = None
        if self.process:
            self.model = nn.Sequential(
                nn.Conv2d(in_filters, nb_filters, (1, 1), stride=subsample)
            )

    def forward(self, x, y):
        if self.process:
            return self.model(x) + y
        return x + y


class _UpShortcut(nn.Module):
    def __init__(self, in_filters, nb_filters, subsample):
        super().__init__()
        self.process = in_filters != nb_filters
        self.model = None
        if self.process:
            self.model = nn.Sequential(
                nn.Conv2d(in_filters, nb_filters, (1, 1), stride=subsample,
                          padding_mode='zeros'),
                nn.Upsample(scale_factor=2, mode='nearest')
            )

    def forward(self, x, y):
        if self.process:
            return self.model(x) + y
        return x + y


class _BasicBlock(nn.Module):
    def __init__(self, in_filters, nb_filters, init_subsample=1):
        super().__init__()
        self.conv1 = _BnReluConv(in_filters, nb_filters, 3, 3, subsample=init_subsample)
        self.residual = _BnReluConv(nb_filters, nb_filters, 3, 3)
        self.shortcut = _Shortcut(in_filters, nb_filters, subsample=init_subsample)

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.residual(x1)
        return self.shortcut(x, x2)


class _UpBasicBlock(nn.Module):
    def __init__(self, in_filters, nb_filters, init_subsample=1):
        super().__init__()
        self.conv1 = _UpBnReluConv(in_filters, nb_filters, 3, 3, subsample=init_subsample)
        self.residual = _BnReluConv(nb_filters, nb_filters, 3, 3)
        self.shortcut = _UpShortcut(in_filters, nb_filters, subsample=init_subsample)

    def forward(self, x):
        return self.shortcut(x, self.residual(self.conv1(x)))


class _ResidualBlock(nn.Module):
    def __init__(self, in_filters, nb_filters, repetitions, is_first_layer=False):
        super().__init__()
        layers = []
        for i in range(repetitions):
            init_subsample = 1
            if i == repetitions - 1 and not is_first_layer:
                init_subsample = 2
            if i == 0:
                layers.append(_BasicBlock(in_filters, nb_filters, init_subsample))
            else:
                layers.append(_BasicBlock(nb_filters, nb_filters, init_subsample))
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


class _UpsamplingResidualBlock(nn.Module):
    def __init__(self, in_filters, nb_filters, repetitions):
        super().__init__()
        layers = []
        for i in range(repetitions):
            if i == 0:
                layers.append(_UpBasicBlock(in_filters, nb_filters))
            else:
                layers.append(_BasicBlock(nb_filters, nb_filters))
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


class MangaLineNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.block0 = _ResidualBlock(1, 24, 2, is_first_layer=True)
        self.block1 = _ResidualBlock(24, 48, 3)
        self.block2 = _ResidualBlock(48, 96, 5)
        self.block3 = _ResidualBlock(96, 192, 7)
        self.block4 = _ResidualBlock(192, 384, 12)

        self.block5 = _UpsamplingResidualBlock(384, 192, 7)
        self.res1 = _Shortcut(192, 192)

        self.block6 = _UpsamplingResidualBlock(192, 96, 5)
        self.res2 = _Shortcut(96, 96)

        self.block7 = _UpsamplingResidualBlock(96, 48, 3)
        self.res3 = _Shortcut(48, 48)

        self.block8 = _UpsamplingResidualBlock(48, 24, 2)
        self.res4 = _Shortcut(24, 24)

        self.block9 = _ResidualBlock(24, 16, 2, is_first_layer=True)
        self.conv15 = _BnReluConv(16, 1, 1, 1, subsample=1)

    def forward(self, x):
        x0 = self.block0(x)
        x1 = self.block1(x0)
        x2 = self.block2(x1)
        x3 = self.block3(x2)
        x4 = self.block4(x3)

        res1 = self.res1(x3, self.block5(x4))
        res2 = self.res2(x2, self.block6(res1))
        res3 = self.res3(x1, self.block7(res2))
        res4 = self.res4(x0, self.block8(res3))

        return self.conv15(self.block9(res4))


# ---------------------------------------------------------------------------
# Lazy model cache. Weights stay in RAM and are moved to the GPU only for the
# duration of the preprocessing, so they never compete with the diffusion model
# for VRAM.
# ---------------------------------------------------------------------------

_loaded_models = {}


def _load_state_dict(model_path: str):
    try:
        ckpt = torch.load(model_path, map_location='cpu', weights_only=True)
    except TypeError:
        # torch < 1.13 has no weights_only argument
        ckpt = torch.load(model_path, map_location='cpu')
    except Exception:
        # some legacy pickles are rejected by the restricted unpickler
        ckpt = torch.load(model_path, map_location='cpu', weights_only=False)

    if isinstance(ckpt, dict) and 'state_dict' in ckpt:
        ckpt = ckpt['state_dict']

    if not isinstance(ckpt, dict):
        raise ValueError(f'[{model_path}] does not contain a state dict.')

    return {k.replace('module.', ''): v for k, v in ckpt.items()}


def _get_model(name: str, model_path: str, builder):
    model = _loaded_models.get(name)
    if model is not None:
        return model

    print(f'[Lineart] Loading preprocessor weights: {model_path}')
    model = builder()
    model.load_state_dict(_load_state_dict(model_path))
    model.eval()
    _loaded_models[name] = model
    return model


def _build_anime_model():
    norm_layer = functools.partial(nn.InstanceNorm2d, affine=False, track_running_stats=False)
    return UnetGenerator(3, 1, 8, 64, norm_layer=norm_layer, use_dropout=False)


def _build_lineart_model():
    return LineartGenerator(3, 1, 3)


# ---------------------------------------------------------------------------
# Preprocessors. They take an RGB uint8 image and return a single channel
# uint8 control image.
#
# All three emit WHITE LINES ON A BLACK CANVAS, which is the convention used by
# comfyui_controlnet_aux (every one of its lineart detectors ends with
# `255 - detected_map`). That is what the NoobAI ControlNets were trained on,
# so do not flip this without retraining. If you ever need the opposite
# polarity, invert the return value of the three functions below.
# ---------------------------------------------------------------------------

def _resolve_device(device):
    """
    `device=None` means "whatever the worker is using", which is what we want
    inside the worker process. The UI preview passes `device='cpu'` explicitly
    because it lives in a different process and must never allocate VRAM that
    the worker needs.
    """
    if device is None:
        return ldm_patched.modules.model_management.get_torch_device()
    return torch.device(device)


def _offload(net, torch_device):
    """
    Move the weights back to RAM and hand the temporary VRAM back to the driver.
    Without the empty_cache() the cached blocks stay reserved by the process and
    the diffusion model that runs right after can fail to find room.
    """
    net.cpu()
    if getattr(torch_device, 'type', str(torch_device)) == 'cuda':
        torch.cuda.empty_cache()


def lineart_realistic(x: np.ndarray, model_path: str, device=None) -> np.ndarray:
    assert isinstance(x, np.ndarray) and x.ndim == 3 and x.shape[2] == 3

    height, width, _ = x.shape

    net = _get_model('lineart_realistic', model_path, _build_lineart_model)
    torch_device = _resolve_device(device)
    net.to(torch_device)

    try:
        with torch.no_grad():
            feed = torch.from_numpy(np.ascontiguousarray(x)).float().to(torch_device)
            feed = feed / 255.0
            feed = feed.permute(2, 0, 1).unsqueeze(0)

            line = net(feed)[0, 0].cpu().numpy() * 255.0
    finally:
        _offload(net, torch_device)

    line = (255.0 - line).clip(0, 255).astype(np.uint8)
    if line.shape[:2] != (height, width):
        line = cv2.resize(line, (width, height), interpolation=cv2.INTER_CUBIC)
    return line


def lineart_anime(x: np.ndarray, model_path: str, device=None) -> np.ndarray:
    assert isinstance(x, np.ndarray) and x.ndim == 3 and x.shape[2] == 3

    height, width, _ = x.shape
    padded_h = 256 * int(math.ceil(float(height) / 256.0))
    padded_w = 256 * int(math.ceil(float(width) / 256.0))

    img = cv2.resize(x, (padded_w, padded_h), interpolation=cv2.INTER_CUBIC)

    net = _get_model('lineart_anime', model_path, _build_anime_model)
    torch_device = _resolve_device(device)
    net.to(torch_device)

    try:
        with torch.no_grad():
            feed = torch.from_numpy(img).float().to(torch_device)
            feed = feed / 127.5 - 1.0
            feed = feed.permute(2, 0, 1).unsqueeze(0)

            line = net(feed)[0, 0] * 127.5 + 127.5
            line = line.cpu().numpy()
    finally:
        _offload(net, torch_device)

    line = cv2.resize(line, (width, height), interpolation=cv2.INTER_CUBIC)
    return (255.0 - line).clip(0, 255).astype(np.uint8)


def manga_line(x: np.ndarray, model_path: str, device=None) -> np.ndarray:
    assert isinstance(x, np.ndarray) and x.ndim == 3 and x.shape[2] == 3

    gray = cv2.cvtColor(x, cv2.COLOR_RGB2GRAY)
    gray = np.ascontiguousarray(gray)

    net = _get_model('manga_line', model_path, MangaLineNet)
    torch_device = _resolve_device(device)
    net.to(torch_device)

    try:
        with torch.no_grad():
            feed = torch.from_numpy(gray).float().to(torch_device)
            feed = feed.unsqueeze(0).unsqueeze(0)

            line = net(feed)
            # The raw output is already white-background line art, but both
            # sd-webui and comfyui_controlnet_aux invert it on purpose so that
            # this preprocessor emits white lines on a black canvas. Do not
            # "fix" this without retraining: the ControlNet expects this polarity.
            line = 255 - line.cpu().numpy()[0, 0]
    finally:
        _offload(net, torch_device)

    return line.clip(0, 255).astype(np.uint8)


# ---------------------------------------------------------------------------
# Public entry point.
#
# Both the UI preview and the worker go through this function, so the image the
# user sees in the "Preview preprocessor" panel is exactly the image the
# ControlNet receives (same weights, same polarity, same resolution handling).
# ---------------------------------------------------------------------------

_PREPROCESSORS = {
    'lineart_anime': lineart_anime,
    'manga_line': manga_line,
    'lineart_realistic': lineart_realistic,
}


def _as_rgb_uint8(x) -> np.ndarray:
    """Normalize whatever the UI hands us (PIL, L, LA, RGB, RGBA, float) to RGB uint8."""
    if not isinstance(x, np.ndarray):
        x = np.asarray(x)

    if x.ndim == 2:
        x = np.stack([x, x, x], axis=2)
    elif x.ndim == 3 and x.shape[2] == 1:
        x = np.repeat(x, 3, axis=2)
    elif x.ndim == 3 and x.shape[2] == 4:
        x = x[:, :, :3]

    if x.dtype != np.uint8:
        x = np.nan_to_num(x).clip(0, 255).astype(np.uint8)

    return np.ascontiguousarray(x)


def preprocess(x, preprocessor_type: str, device=None) -> np.ndarray | None:
    """
    Convert a normal image into the control image for the given Lineart ControlNet.

    Returns a single channel uint8 array with WHITE LINES ON A BLACK CANVAS.
    """
    if x is None:
        return None

    import modules.config
    import modules.flags as lineart_flags

    key = {
        lineart_flags.cn_lineart_anime: 'lineart_anime',
        lineart_flags.cn_manga_line: 'manga_line',
        lineart_flags.cn_lineart_realistic: 'lineart_realistic',
    }.get(preprocessor_type)

    if key is None:
        raise ValueError(f'Unknown lineart preprocessor: {preprocessor_type}')

    model_path = modules.config.downloading_lineart_preprocessor(preprocessor_type)

    return _PREPROCESSORS[key](_as_rgb_uint8(x), model_path, device=device)
