"""Verifica el orden de llamadas de refresh_base_model() sin importar Fooocus.

Extrae las funciones del AST para no arrastrar numpy/torch/ldm_patched.
"""
import ast
import os
import sys
import types

SRC = os.path.join(os.path.dirname(__file__), '..', '..', 'modules', 'default_pipeline.py')
SRC = os.path.abspath(SRC)

WANTED = ('release_checkpoint_memory', 'refresh_base_model')

tree = ast.parse(open(SRC, encoding='utf-8').read())
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in WANTED]
assert len(nodes) == 2, [n.name for n in nodes]

events = []


class FakeTorch(types.ModuleType):
    def no_grad(self):
        return lambda f: f

    def inference_mode(self):
        return lambda f: f


class SDM:
    def __init__(self, unet=None, vae=None, clip=None, clip_vision=None,
                 filename=None, vae_filename=None):
        self.unet = unet
        self.vae = vae
        self.clip = clip
        self.filename = filename
        self.vae_filename = vae_filename


class Core:
    StableDiffusionModel = SDM

    @staticmethod
    def load_model(filename, vae_filename=None):
        # Lo importante: en este punto el modelo viejo ya no debe estar vivo.
        events.append(('load_model', filename, ns['model_base'].unet))
        m = SDM(filename=filename, vae_filename=vae_filename)
        m.unet = object()
        return m


def unload_all_models():
    events.append(('unload_all_models', ns['model_base'].unet))


def soft_empty_cache():
    events.append(('soft_empty_cache', None))


mm = types.SimpleNamespace(unload_all_models=unload_all_models,
                           soft_empty_cache=soft_empty_cache)
ldm = types.SimpleNamespace(model_management=mm)
ldm_patched = types.SimpleNamespace(modules=ldm)

config = types.SimpleNamespace(paths_checkpoints=['/ckpt'], path_vae=['/vae'])
flags = types.SimpleNamespace(default_vae='Default VAE (sd-vae-ft-mse)')

ns = {
    'torch': FakeTorch('torch'),
    'core': Core,
    'ldm_patched': ldm_patched,
    'modules': types.SimpleNamespace(config=config, flags=flags),
    'get_file_from_folder_list': lambda name, paths: os.path.join(paths[0], name),
    'model_base': SDM(filename='/ckpt/a.safetensors'),
    'model_refiner': SDM(),
}
ns['model_base'].unet = 'OLD_UNET'
ns['model_base'].vae_filename = None

exec(compile(ast.Module(body=nodes, type_ignores=[]), '<pipeline-extract>', 'exec'), ns)

fails = []


def check(label, cond, extra=''):
    print(('  OK   ' if cond else '  FAIL ') + label + (('  ' + extra) if extra and not cond else ''))
    if not cond:
        fails.append(label)


# --- Caso 1: mismo modelo -> no se descarga nada -------------------------
events.clear()
ns['model_base'] = SDM(filename=os.path.join('/ckpt', 'a.safetensors'))
ns['model_base'].unet = 'OLD_UNET'
ns['model_base'].vae_filename = None
ns['refresh_base_model']('a.safetensors')
check('mismo modelo: no descarga', events == [], str(events))

# --- Caso 2: modelo nuevo -> descarga ANTES de cargar --------------------
events.clear()
ns['model_base'] = SDM(filename='/ckpt/a.safetensors')
ns['model_base'].unet = 'OLD_UNET'
ns['model_base'].vae_filename = None
ns['model_refiner'] = SDM()
ns['refresh_base_model']('b.safetensors')

names = [e[0] for e in events]
check('modelo nuevo: unload antes de load_model',
      names.index('unload_all_models') < names.index('load_model'), str(names))
check('modelo nuevo: empty_cache antes de load_model',
      names.index('soft_empty_cache') < names.index('load_model'), str(names))

load_evt = [e for e in events if e[0] == 'load_model'][0]
check('modelo nuevo: el UNet viejo ya no esta referenciado al cargar',
      load_evt[2] is None, repr(load_evt[2]))
check('modelo nuevo: se libera antes de que load_model toque la GPU',
      [e for e in events if e[0] == 'unload_all_models'][0][1] is None,
      repr([e for e in events if e[0] == 'unload_all_models']))

# --- Caso 3: refiner sintetico que comparte el UNet ----------------------
events.clear()
base = SDM(filename='/ckpt/a.safetensors')
base.unet = 'OLD_UNET'
ns['model_base'] = base
shared = SDM(unet='OLD_UNET', filename='/ckpt/a.safetensors')
ns['model_refiner'] = shared
ns['refresh_base_model']('c.safetensors')
check('refiner sintetico: se descarta el alias del UNet viejo',
      ns['model_refiner'] is not shared and ns['model_refiner'].unet is None,
      repr(ns['model_refiner'].unet))

# --- Caso 4: refiner real (UNet distinto) se conserva -------------------
events.clear()
base = SDM(filename='/ckpt/a.safetensors')
base.unet = 'OLD_UNET'
ns['model_base'] = base
real = SDM(unet='REFINER_UNET', filename='/ckpt/r.safetensors')
ns['model_refiner'] = real
ns['refresh_base_model']('d.safetensors')
check('refiner real: no se toca', ns['model_refiner'] is real)

print()
if fails:
    print(f'{len(fails)} FALLOS')
    sys.exit(1)
print('todo correcto')
